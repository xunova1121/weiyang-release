import { presentationAnswerIssues } from './presentationReceipt.js';
import { repositoryReceipt, repositoryRepair, repositoryDeliveryIssue, correctRepositoryLinks, repositoryTextStream } from './codeRepositoryReview.js';
import { IMAGE_RECHECK } from './imageReading.js';
import { newsCandidates } from './newsDelivery.js';
import { mediaReceipt, mediaDelivery, blockedAfterDenial } from './actionDelivery.js';
import { createVisualEvidence, readVisualReceipt } from './visualEvidence.js';
import { taskContract } from './taskContract.js';
import { isReadOnlyTool } from '../../shared/taskCheckpoint.js';
import { creativeWithoutLookup } from '../core/imageFollowup.js';
import { answerConstraints, answerConstraintIssues, concreteSourceRequirement, sourceCandidates, sourceAnswerIssue } from './answerRequirements.js';
import { styleRequests, styleIssues, styleNote } from './styleCheck.js';
import { completedDeliverySteps } from './deliveryCompletion.js';
import { priceComparisonIssues } from './priceComparison.js';
import { reconcileAnswerIssues, conflictingNumbers, weatherConflicts } from './numberReconcile.js';
/** 问的是数字类事实（几条、多少、排第几、里程、人口……）：交付前查同一回答里有没有前后不一致的数 */
const NUMERIC_FACT = /多少|几条|几个|几座|第几|排名|排第|里程|人口|面积|总量|规模|金额|营收|产量|占比/;

/** 核实文件内容的工具：同一文件验过可用后只再放行一次 */
export const VERIFY_TOOLS = /^(?:read_file|computer_read_file|check_document)$/;
/** 每轮仅存最多64条回执摘要，不保存正文、代码或网页。不同任务不共享。 */
const DOC_TOOLS = /^(?:build_architecture|create_diagram|export_diagram|create_document|write_long_document|write_professional_document|edit_office_document|edit_spreadsheet)$/;

export function createExecutionReview(goal = '', { visual = false } = {}) {
  let request = String(goal).slice(0, 4000);
  const receipts = [];
  const visualEvidence = createVisualEvidence(visual || /截图|识图|OCR|看图|图片识字/.test(goal), { requireRecheck: IMAGE_RECHECK.test(goal) });
  let visualIssue = '';
  let declinedTool = '';
  const toolBlock = (toolName) => blockedAfterDenial(request, declinedTool, toolName);
  const files = new Map();
  const projectScopes = new Map(); // 每轮至多32个已实际读取/写入的package.json项目边界。
  const artifacts = new Map();
  const reads = new Map(); // 文件路径 → 验过可用之后又读了几次（最多 32 个文件）
  let version = 0;
  let repositoryChanged = false;
  let sequence = 0;
  let answerIssues = [];
  let numberDecisions = [];
  let sourceIssue = '';
  let calculationIssue = '';
  let styleProblems = [];
  const candidateSources = new Set();
  const newsOriginals = new Set(); // 只存本轮最多24个实际新闻URL，不存正文。
  const newsRead = new Set();
  let selectedNews = new Set();
  const newsOriginalIssue = () => /打开.{0,8}原文|核实原文|原文核实|查原文|核对原文/.test(request) && newsOriginals.size && (selectedNews.size ? [...selectedNews].some(url => !newsRead.has(url)) : !newsRead.size) ? '用户要求打开报道原文核实，目前只取得汇总页条目；请并发读取选用报道的原文，未读部分保留具体内容并标待核实，不能称核实完成' : '';
  const newsLinks = new Map(); // 仅本轮最多8条候选标题/网址，不保存摘要。
  const revise = (text) => {
    const previous = taskContract(request);
    const replaceLookup = previous.researching && !previous.formats.length && !previous.coding && !previous.remembering && !previous.askingMemory
      && !files.size && !artifacts.size && !/文档|报告|方案|表格|代码|程序/.test(request)
      && /^(?:改成|改为|换成|换为)/.test(String(text).trim()) && creativeWithoutLookup(text);
    request = (request + '\n补充：' + String(text)).slice(-4000);
    version++;
    declinedTool = '';
    answerIssues = [];
    styleProblems = [];
    sourceIssue = '';
    calculationIssue = '';
    candidateSources.clear();
    newsLinks.clear();
    newsOriginals.clear();
    newsRead.clear();
    selectedNews.clear();
    // 仅简单查询明确转创作时替换目标；文档“改成两页”等仍须保留原交付要求。
    if (/^(?:取消|不用|别做|停止)/.test(String(text).trim()) || replaceLookup) {
      request = '用户最新修正：' + String(text).slice(0, 3900);
      files.clear();
      projectScopes.clear();
      artifacts.clear();
    }
  };
  const record = ({ name: toolName, args = {}, ok, validation, output = '', code = '' }) => {
    // 数字定案结果：交付前核对回答只用主数字（最多保留 12 组）
    if (ok && toolName === 'reconcile_numbers') { try { numberDecisions = [...numberDecisions, ...(JSON.parse(output).decisions || [])].slice(-12); } catch { /* 回执不是 JSON 时不记 */ } }
    let dataRetrieved;
    if (ok && ['search_tenders', 'read_tender_notice', 'lookup_company'].includes(toolName)) {
      try { const value = JSON.parse(output); dataRetrieved = Boolean(value.evidence === 'original_page' || value.items?.length || value.rows?.length); }
      catch { dataRetrieved = false; }
    }
    if (ok && toolName === 'get_today_news') {
      try {
        const value = JSON.parse(output);
        dataRetrieved = value.kind === 'today_news' && value.items?.length > 0;
        for (const item of (value.items || []).slice(0, 24)) if (newsOriginals.size < 24 && /^https:\/\//.test(item.url)) newsOriginals.add(item.url);
      } catch { dataRetrieved = false; }
    }
    if (ok && toolName === 'fetch_url' && newsOriginals.has(args.url) && !/^原网页读取失败/.test(String(output))) newsRead.add(args.url);
    if (ok && toolName === 'web_search' && answerConstraints(request).todayNews) {
      for (const item of newsCandidates(output)) {
        if (newsLinks.size < 8) newsLinks.set(item.url, item);
      }
    }
    if (ok) for (const url of sourceCandidates(request, toolName, output, args)) {
      if (candidateSources.size < 8) candidateSources.add(url);
    }
    if (toolName === 'inspect_image') {
      visualEvidence.note({ kind: 'ocr', ok: false });
      visualEvidence.note(ok ? readVisualReceipt(output) || { kind: 'vision', ok: false } : { kind: 'vision', ok: false });
    }
    if (toolName === 'read_image_text') visualEvidence.note(ok ? readVisualReceipt(output) || { kind: 'ocr', ok: true } : { kind: 'ocr', ok: false });
    if (!ok && code === 'NOT_APPROVED') declinedTool = toolName;
    const media = mediaReceipt(toolName, ok, output);
    const path = typeof args.path === 'string' ? args.path.slice(0, 400) : '';
    sequence++;
    const repository = repositoryReceipt(toolName, args, ok, output);
    if (ok && repository?.workspaceId && /(?:^|\/)package\.json$/.test(path) && projectScopes.size < 32) {
      projectScopes.set(repository.workspaceId + ':' + path, { workspaceId: repository.workspaceId, dir: path === 'package.json' ? '.' : path.slice(0, -13) });
    }
    if (ok && /^code_(?:edit|write)$/.test(toolName)) repositoryChanged = true;
    receipts.push({
      tool: toolName,
      ok: Boolean(ok),
      ...(dataRetrieved !== undefined && { dataRetrieved }),
      ...(repository || {}),
      ...(media && { media }),
      ...(['NOT_APPROVED', 'TASK_SCOPE_AFTER_DENIAL'].includes(code) && { code }),
      path,
      version,
      sequence,
      key: toolName + ':' + path + ':' + String(args.query ?? args.url ?? '').slice(0, 200) + (repository ? ':' + repository.workspaceId + ':' + repository.command + ':' + repository.projectDir : '')
    });
    if (receipts.length > 64) receipts.shift();
    // 文件被改了：之前的“已验过”作废；生成工具自己在这次调用里发来的验收结果（at 是这次调用的序号）保留
    if (ok && path && !isReadOnlyTool(toolName) && !VERIFY_TOOLS.test(toolName)) {
      const item = artifacts.get(path);
      if (item && item.at !== sequence) item.stale = true;
      reads.delete(path);
    }
    if (ok && path && VERIFY_TOOLS.test(toolName) && verified(path)) {
      reads.set(path, (reads.get(path) ?? 0) + 1);
      if (reads.size > 32) reads.delete(reads.keys().next().value);
    }
    if (ok && /^(?:write_file|edit_file|computer_write_file|computer_edit_file)$/.test(toolName) && path) {
      // 每次写入都会使旧测试失效；预览和“已运行某段代码”不能证明这个文件通过测试。
      files.set(path, { path, written: sequence, verified: false });
      if (files.size > 32) files.delete(files.keys().next().value);
    }
    if (ok && /^(?:read_file|computer_read_file)$/.test(toolName) && files.has(path)) files.get(path).verified = true;
    if (ok && /^(?:read_file|computer_read_file)$/.test(toolName) && files.has(path) && /\.(?:pptx|docx|xlsx)$/i.test(path)) {
      // 普通读回不抹掉同一未修改文件的真实Office检查；写入后的旧证据仍失效。
      if (!verified(path)) artifact({ path, validation: { format: path.split('.').pop().toLowerCase(), readback: 'passed', structure: 'not_checked', render: 'not_checked' } }, sequence);
    }
    if (ok && repository?.workspaceId && path) {
      const key = repository.workspaceId + ':' + path;
      if (/^code_(?:edit|write)$/.test(toolName)) {
        files.set(key, { path, workspaceId: repository.workspaceId, written: sequence, verified: false });
        if (files.size > 32) files.delete(files.keys().next().value);
      }
      if (toolName === 'code_read' && files.has(key)) files.get(key).verified = true;
    }
    if (validation) return validation;
  };
  // 验收结果通常在工具运行中发来，那次调用记回执时序号才加一，所以默认记成 sequence + 1
  const artifact = (event, at = sequence + 1) => {
    if (!event || typeof event.path !== 'string') return;
    const data = event.validation ?? {};
    artifacts.set(event.path.slice(0, 400), {
      path: event.path.slice(0, 400),
      format: String(data.format || '').slice(0, 8),
      ...(data.wordCount && { wordCount: { count: data.wordCount.count, min: data.wordCount.min, max: data.wordCount.max, passed: data.wordCount.passed === true } }),
      readback: data.readback,
      structure: data.structure,
      render: data.render,
      ...(data.designHash && { designHash: String(data.designHash).slice(0, 90) }),
      ...(data.consistency && { consistency: String(data.consistency).slice(0, 40) }),
      ...(data.visual && { visual: ['passed', 'failed'].includes(data.visual) ? data.visual : 'not_checked' }),
      ...(data.business && { business: data.business === 'source_excerpts_matched' ? data.business : 'not_checked' }),
      errors: Math.max(0, Number(data.errors) || 0),
      slides: Number.isSafeInteger(data.slides) ? data.slides : null,
      expectedSlides: Number.isSafeInteger(data.expectedSlides) ? data.expectedSlides : null,
      pages: Number.isSafeInteger(data.pages) ? data.pages : null,
      pdfPageMatch: data.pdfPageMatch === 'passed' ? 'passed' : data.pdfPageMatch === 'failed' ? 'failed' : null,
      ...(data.styleFacts && { styleFacts: data.styleFacts }),
      ...(data.presentation && { presentation: { imagePages: data.presentation.imagePages, missingImagePages: (data.presentation.missingImagePages || []).slice(0, 300) } }),
      // 同一文件第二次回执（渲染后）没带上一版时，沿用第一次的基准
      previousStyle: event.previousStyle ?? artifacts.get(event.path.slice(0, 400))?.previousStyle ?? null,
      at
    });
    if (artifacts.size > 16) artifacts.delete(artifacts.keys().next().value);
  };
  /** 文件已经验过：能读回、生成器没报错，之后也没被改过 */
  function verified(path) {
    const item = artifacts.get(String(path ?? '').slice(0, 400));
    return Boolean(item && !item.stale && item.readback === 'passed' && !item.errors);
  }
  /** 同一文件验过可用后，再核实最多放行一次；之后直接告诉模型不用再读 */
  const rereadBlocked = (name, args = {}) => VERIFY_TOOLS.test(name) && verified(args.path) && (reads.get(String(args.path).slice(0, 400)) ?? 0) >= 1;
  const required = () => {
    const contract = taskContract(request);
    return Boolean(contract.media) || Boolean(concreteSourceRequirement(request)) || answerIssues.length > 0 || contract.formats.length > 0 || contract.coding || contract.remembering || contract.askingMemory || files.size > 0 || artifacts.size > 0 || receipts.some(receipt => ['verify_numbers', 'time_calc'].includes(receipt.tool) && !receipt.ok || receipt.ok && /^(?:create_document|write_long_document|write_professional_document|edit_office_document|edit_spreadsheet|write_file|edit_file|run_javascript|run_python|computer_run|run_project_tests)$/.test(receipt.tool));
  };
  const contractNote = () => {
    if (!required()) return '';
    const contract = taskContract(request);
    return contract.criteria.length
      ? '本轮交付验收：' + contract.criteria.join('；') + '。用review_task核对真实回执；缺少验证时如实报告，不能靠计划标完成。'
      : '';
  };
  const report = () => {
    const codeFiles = [...files.values()].filter((file) => /\.(?:[cm]?js|jsx|tsx?|py|html|css|json)$/i.test(file.path) || file.workspaceId && /\.(?:vue|svelte|sh|ya?ml|toml)$/i.test(file.path));
    const lastWrite = Math.max(0, ...codeFiles.map((file) => file.written));
    const current = receipts.filter((receipt) => receipt.version === version);
    const lastNumeric = current.filter(receipt => ['verify_numbers', 'time_calc'].includes(receipt.tool)).at(-1);
    const latest = new Map(current.map((receipt) => [receipt.key, receipt]));
    // 算“失败回执”的只有改东西、跑测试的操作：查资料没查到（门票没搜到）是信息缺口，在交付里标明即可；
    // 后来同一个工具又成功了（换了文件名重新生成）也算已解决
    // 同一份文档：改失败后又用别的文档工具成功生成 / 改好了，也算已解决
    // 同一份文档：改失败后又用别的文档工具生成好了（另存了新文件名也算，格式相同即可），失败已经补救
    // （第一轮 30 题实测：改原文件失败、另存新版成功，结尾仍挂“这些操作没成功：修改文档”）
    const office = (p) => (String(p || '').match(/\.(docx|pptx|xlsx)$/i)?.[1] || '').toLowerCase();
    const sameDoc = (a, b) => DOC_TOOLS.test(a.tool) && DOC_TOOLS.test(b.tool) && Boolean(a.path) && (a.path === b.path || (office(a.path) && office(a.path) === office(b.path)) || !b.path);
    const unresolved = (receipt) =>
      !receipt.ok && receipt.code !== 'TASK_SCOPE_AFTER_DENIAL' &&
      (!isReadOnlyTool(receipt.tool) || receipt.tool === 'run_project_tests') &&
      !current.some((later) => later.sequence > receipt.sequence && later.ok && (receipt.workspaceId ? repositoryRepair(receipt, later) : later.tool === receipt.tool || sameDoc(later, receipt)));
    const legacyRan = receipts.some(
      (receipt) => receipt.sequence > lastWrite && receipt.ok && /^(?:run_javascript|run_python|computer_run|run_project_tests)$/.test(receipt.tool)
    );
    const ran = codeFiles.every(file => {
      if (!file.workspaceId) return legacyRan;
      const projectDir = [...projectScopes.values()].filter(scope => scope.workspaceId === file.workspaceId && (scope.dir === '.' || file.path.startsWith(scope.dir + '/'))).sort((a, b) => b.dir.length - a.dir.length)[0]?.dir || '.';
      const latestTest = current.filter(item => item.tool === 'code_run' && item.workspaceId === file.workspaceId && item.command === 'test' && item.projectDir === projectDir).at(-1);
      return latestTest?.sequence > file.written && latestTest.ok && latestTest.testVerified;
    });
    const pending = [...files.values()].filter((file) => !file.verified && (file.workspaceId || codeFiles.includes(file))).map((file) => file.path);
    const codeFailures = [...latest.values()].filter(receipt => receipt.tool === 'code_run' && unresolved(receipt));
    return {
      media: mediaDelivery(request, receipts.filter((receipt) => receipt.version === version)),
      pendingFormats: taskContract(request).formats.filter(
        (format) => ![...artifacts.values()].some((item) => item.format === format && item.readback === 'passed' && !item.errors)
      ),
      request,
      retrievalReceipts: receipts.filter((receipt) => receipt.version === version && receipt.ok && receipt.dataRetrieved !== false && /^(?:search_tenders|read_tender_notice|lookup_company|get_today_news|fetch_json|web_search|fetch_url|fact_check|deep_research|get_weather|get_stock_kline|get_market_quote|get_sports_scores|read_evidence)$/.test(receipt.tool)).length,
      version,
      calls: sequence,
      answerIssues: [...answerIssues],
      styleIssues: [...styleProblems],
      sourceIssue: sourceIssue || newsOriginalIssue(),
      visualIssue,
      visualReceipts: visualEvidence.snapshot(),
      calculationIssue,
      sourceRequirement: concreteSourceRequirement(request),
      candidateSources: [...candidateSources],
      // 说“记住了 / 记进去了”必须有真实的记忆工具回执
      memory: !taskContract(request).remembering
        ? 'not_required'
        : current.some((receipt) => receipt.ok && /^(?:remember|core_memory_update|save_skill)$/.test(receipt.tool))
          ? 'saved'
          : 'not_saved',
      memoryChecked: !taskContract(request).askingMemory || current.some((receipt) => receipt.ok && receipt.tool === 'recall'),
      calculation: lastNumeric && !lastNumeric.ok ? 'failed' : receipts.some((receipt) => receipt.version === version && receipt.ok && /^(?:verify_numbers|time_calc|run_javascript|run_python)$/.test(receipt.tool))
        ? 'tool_checked'
        : 'not_checked',
      contract: taskContract(request),
      // 同一轮里后来又生成了同格式、检查无错的新文件：旧文件的检查错误不再算“未解决”（第二轮 30 题：改排版失败的中间版挂着错误，最终版没问题，结尾却写“部分完成”）
      artifacts: [...artifacts.values()].filter((item) => !(item.errors > 0 && [...artifacts.values()].some((later) => later.at > item.at && later.format === item.format && !later.errors && later.readback === 'passed'))),
      failures: [...latest.values()].filter(unresolved).map((receipt) => receipt.tool),
      diagnosticRepositoryTest: !repositoryChanged && codeFailures.length > 0 && codeFailures.every(receipt => receipt.diagnosticTest),
      pendingReadback: pending,
      codeExecution: !codeFiles.length ? 'not_required' : ran ? 'executed_scope_needs_review' : 'not_run',
      note: '回执不是完整需求验收；运行任意代码、打开预览不等于所有交付文件测试通过。'
    };
  };
  const guidance = () => {
    const result = report();
    const issues = [];
    issues.push(...result.answerIssues);
    const style = styleNote(request, lastDocument());
    if (style) issues.push(style);
    if (result.visualIssue) issues.push(result.visualIssue);
    if (result.media && result.media.state !== 'completed') issues.push(`用户要求生成${result.media.label}，当前${result.media.state}；应实际调用${result.media.tool}取得文件，不能只写“我来做”收尾。已有歌词/文字保留，失败明确区分，不能虚构下载或播放。`);
    if (result.sourceIssue) issues.push(result.sourceIssue);
    if (result.calculation === 'failed') issues.push('关键verify_numbers校验失败；先根据工具错误修正参数重算，无法核验则明确校验失败、请人工复核，不能声称已通过');
    if (result.pendingFormats.length)
      issues.push('这些要求的文件还没有有效产物读回回执：' + result.pendingFormats.join('、') + '；先实际生成并核对，不能只说已完成');
    if (result.contract.calculation && result.calculation === 'not_checked')
      issues.push('涉及确定性数值计算，但还没有verify_numbers或代码计算回执；先计算核对，不能自行心算冒充已验证');
    if (result.memory === 'not_saved')
      issues.push('用户要你记住，但本轮没有调用 remember 保存（做事方式的教训用 category: lesson）；现在调用，保存成功前不能说“记住了”');
    if (!result.memoryChecked) issues.push('用户问有没有记住：先用 recall 查，查到了再回答，查不到就如实说没记，并问要不要现在记');
    if (result.pendingReadback.length) issues.push('这些修改尚未读回核对：' + result.pendingReadback.join('、'));
    if (result.codeExecution === 'not_run') issues.push('已修改代码但没有实际运行记录；先运行适用测试，无法执行就明确未验证');
    if (result.artifacts.some(item => item.format === 'svg' && (item.visual !== 'passed' || item.business !== 'passed'))) issues.push('架构图按实际回执交付；摘录匹配不等于业务全面核实，未完成视觉检查要说明，不要为补状态重复生成');
    if (result.artifacts.some((item) => item.errors > 0)) issues.push('文档仍有生成器报告的问题，不能宣称排版或公式全部通过');
    if (result.failures.length)
      issues.push('本轮这些操作失败后没有成功补做：' + [...new Set(result.failures)].join('、') + '；补做只指重试失败的这一步（不能改做用户这次没要求的别的事），没补救的在回答里一句话说明，不要为此重新读取已交付的文件');
    return issues.length ? '交付回执核对：' + issues.join('；') + '。不要重复操作或编造测试通过。' : '';
  };
  const tool = {
    name: 'review_task',
    description: '读取本轮原始目标、补充版本与真实执行回执摘要；结束前核对，不能用计划勾选替代实际文件/测试回执。',
    input_schema: { type: 'object', properties: {}, additionalProperties: false },
    run: async () => JSON.stringify(report())
  };
  // 最后生成 / 修改的那份 Office 文件（核对“字大点、不要横线”这类改动用）
  const lastDocument = () => [...artifacts.values()].filter((item) => /^(?:docx|pptx|xlsx)$/.test(item.format)).sort((a, b) => a.at - b.at).at(-1) ?? null;
  const checkAnswer = (text, now) => {
    selectedNews = new Set((String(text).match(/https?:\/\/[^\s)）\]，。]+/g) || []).filter(url => newsOriginals.has(url)));
    answerIssues = [...answerConstraintIssues(request, text, now), ...priceComparisonIssues(request, text), ...presentationAnswerIssues(request, text, lastDocument())];
    // 数字定案（用户 2026-11-05：南京地铁 611 / 757 / 556.8 公里同时出现）：用了定案就只用主数字；没定案时查明显的前后不一致
    answerIssues.push(...(numberDecisions.length ? reconcileAnswerIssues(text, numberDecisions) : numericLookup() ? conflictingNumbers(text) : []));
    if (weatherAsked()) answerIssues.push(...weatherConflicts(text));
    if (repositoryChanged) {
      const issue = repositoryDeliveryIssue(text, [...new Set([...files.values()].map(file => file.workspaceId).filter(Boolean))]);
      if (issue) answerIssues.push(issue);
    }
    styleProblems = styleIssues(request, text, lastDocument());
    visualIssue = visualEvidence.issue(text);
    sourceIssue = sourceAnswerIssue(request, text, [...candidateSources]) || newsOriginalIssue();
    const result = report();
    calculationIssue = result.calculation === 'failed' ? '关键verify_numbers校验失败，修正输入重算；不能核验时必须明确校验失败、请人工复核' : result.contract.calculation && result.calculation === 'not_checked' ? '关键计算尚无工具校验，请先调用verify_numbers核对，不能用心算冒充工具结果' : '';
    return [...answerIssues, ...styleProblems, ...(visualIssue ? [visualIssue] : []), ...(sourceIssue ? [sourceIssue] : []), ...(calculationIssue ? [calculationIssue] : [])];
  };
  /** 数字类事实问题，且本轮至少有两次联网取得资料 */
  // 查过天气或问的是天气：回答里同一天的最高 / 最低温不能前后两个数
  const weatherAsked = () => /天气|气温|温度|穿衣|下雨/.test(String(request)) || receipts.some(r => r.ok && r.tool === 'get_weather');
  const numericLookup = () => NUMERIC_FACT.test(String(request)) && receipts.filter(r => r.ok && /^(?:web_search|fetch_url|fetch_json|deep_research|fact_check)$/.test(r.tool)).length >= 2;
  const guardsAnswer = () => {
    const rules = answerConstraints(request);
    return numberDecisions.length > 0 || numericLookup() || weatherAsked() || lastDocument()?.format === 'pptx' || visualEvidence.active() || (styleRequests(request).length > 0 && Boolean(lastDocument())) || rules.noTime || rules.literals.length > 0 || rules.todayNews || rules.care || rules.priceComparison || Boolean(concreteSourceRequirement(request)) || taskContract(request).calculation || report().calculation === 'failed';
  };
  /** 改写一次后仍对不上：不吞掉回答（文件链接要留着），末尾补一句读回的实际情况 */
  const styleCorrection = () => (styleProblems.length ? '（读回文件核对：' + styleNote(request, lastDocument()).replace(/^用户要的调整，读回文件的实际结果：/, '').replace(/。回答照这个说$/, '') + '。）' : '');
  const repositoryText = text => repositoryChanged ? correctRepositoryLinks(text, [...new Set([...files.values()].map(file => file.workspaceId).filter(Boolean))]) : text;
  const repositoryStream = () => repositoryChanged ? repositoryTextStream(repositoryText) : { push: fragment => fragment };
  const completeDelivery = (steps, answer) => completedDeliverySteps({ report: report(), guidance: guidance(), receipts, steps, answer });
  return { completeDelivery, repositoryStream, repositoryText, styleCorrection, newsCandidates: () => [...newsLinks.values()], toolBlock, noteVisual: visualEvidence.note, record, revise, report, guidance, tool, artifact, contractNote, required, verified, rereadBlocked, checkAnswer, guardsAnswer };
}
