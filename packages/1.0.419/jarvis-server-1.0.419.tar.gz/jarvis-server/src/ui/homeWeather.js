import { renderWeatherDetails, weatherOverview, weatherTravelAdvice } from './weatherDetails.js';
import './weatherCard.css';
import { POPULAR_CITIES, weatherKind, cityKey } from '../core/weather.js';
import { createWeatherFollow, WEATHER_LOCATION_INTERVAL } from '../core/weatherFollow.js';

export function weatherSVG(kind = 'sun', night = false) {
  const paths = {
    sun: night
      ? '<path d="M19 15A8 8 0 0 1 9 5a8 8 0 1 0 10 10z"/>'
      : '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/>',
    cloud: '<path d="M6 18a4 4 0 0 1-.5-8A6 6 0 0 1 17 8a5 5 0 0 1 1 10z"/>',
    rain: '<path d="M6 15a4 4 0 0 1-.5-8A6 6 0 0 1 17 7a4 4 0 0 1 1 8M8 18l-1 3m6-3-1 3m6-3-1 3"/>',
    snow: '<path d="M6 14a4 4 0 0 1-.5-7A6 6 0 0 1 17 7a4 4 0 0 1 1 7M8 17v5m-2.2-3.8 4.4 2.6m-4.4 0 4.4-2.6M17 17v5m-2.2-3.8 4.4 2.6m-4.4 0 4.4-2.6"/>',
    storm: '<path d="M6 15a4 4 0 0 1-.5-8A6 6 0 0 1 17 7a4 4 0 0 1 1 8M13 13l-4 6h5l-3 4"/>',
    fog: '<path d="M6 12a4 4 0 0 1-.5-7A6 6 0 0 1 17 5a4 4 0 0 1 1 7M4 16h16M6 20h12"/>'
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[kind] || paths.cloud}</svg>`;
}
const node = (tag, text, className) =>
  Object.assign(document.createElement(tag), { ...(text !== undefined ? { textContent: text } : {}), ...(className ? { className } : {}) });
const degrees = (value) => (typeof value === 'number' && Number.isFinite(value) ? `${Math.round(value)}°` : '—');
export async function locateWeatherCity({ maximumAge = 0, requestPermission = true } = {}) {
  if (globalThis.Capacitor?.isNativePlatform?.()) {
    const { registerPlugin } = await import('@capacitor/core');
    const p = await registerPlugin('WeatherLocation').locate({ maximumAge, requestPermission });
    return {
      name: p.name === '附近' ? '当前位置' : p.name || '当前位置',
      ...(p.city && { city: p.city }),
      ...(p.district && { district: p.district }),
      latitude: p.latitude,
      longitude: p.longitude,
      source: 'location'
    };
  }
  if (!navigator.geolocation) throw new Error('当前环境不支持定位，请手动选城市');
  const p = await new Promise((resolve, reject) =>
    navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: false, timeout: 10000, maximumAge })
  ).catch((error) => {
    throw new Error(error.code === 1 ? '定位未允许，可以手动选择城市' : '暂时没有定位结果，可以手动选择城市');
  });
  const lat = p.coords.latitude,
    lon = p.coords.longitude,
    city = POPULAR_CITIES.find((c) => Math.hypot(c.latitude - lat, (c.longitude - lon) * Math.cos((lat * Math.PI) / 180)) < 0.3);
  return { name: city?.name || '当前位置', latitude: Math.round(lat * 100) / 100, longitude: Math.round(lon * 100) / 100, source: 'location' };
}

// 只查权限、不弹授权框：没授权就不做后台定位（用户 2026-11-01：天气刷新和定位要无感）
export async function locationGranted() {
  try {
    if (globalThis.Capacitor?.isNativePlatform?.()) {
      const { registerPlugin } = await import('@capacitor/core');
      const p = await registerPlugin('WeatherLocation').checkPermissions();
      return p?.location === 'granted';
    }
    const p = await navigator.permissions?.query?.({ name: 'geolocation' });
    return p?.state === 'granted';
  } catch {
    return false;
  }
}
// 两个坐标相距多少公里（城市范围内够用的近似）
export const distanceKm = (a, b) => Math.hypot(a.latitude - b.latitude, (a.longitude - b.longitude) * Math.cos((a.latitude * Math.PI) / 180)) * 111;
export const WEATHER_AUTO_REFRESH = 15 * 60 * 1000;
export const WEATHER_RELOCATE_GAP = WEATHER_LOCATION_INTERVAL;

// 只合并正在进行的首次定位，不把一次坐标永久缓存到整个App会话。
let pendingLocation;
const locateOnce = () =>
  (pendingLocation ??= locateWeatherCity().finally(() => {
    pendingLocation = null;
  }));
export function createHomeWeather({
  client,
  onAdvice,
  onConfigure,
  locate = locateOnce,
  checkLocation = locationGranted,
  quietLocate = locateWeatherCity,
  now = () => Date.now()
} = {}) {
  const root = node('section', undefined, 'home-weather');
  root.id = 'homepage-weather';
  root.setAttribute('aria-label', '日期与天气');
  root.innerHTML =
    '<div class="home-weather-top"><span class="home-date"></span><div class="home-city"><button type="button" class="home-weather-details" aria-label="查看天气详情"><span class="home-weather-icon"></span><span class="home-weather-place"><b>选择城市</b><small class="home-weather-condition">查看天气</small></span><strong class="home-weather-temp">—</strong></button><button type="button" class="home-weather-location" aria-label="切换天气位置"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 10 5 5 5-5"/></svg></button></div></div><div class="home-weather-bottom"><span class="home-weather-summary" role="status">选个城市，看看出门的天气</span></div>';
  root.querySelector('.home-date').textContent = new Intl.DateTimeFormat('zh-CN', { month: 'long', day: 'numeric', weekday: 'long', timeZone: 'Asia/Shanghai' })
    .format(new Date())
    .replace('日', '日 · ');
  const dialog = node('dialog', undefined, 'weather-dialog');
  dialog.id = 'homepage-weather-dialog';
  dialog.setAttribute('aria-labelledby', 'weather-dialog-title');
  dialog.innerHTML =
    '<header><h2 id="weather-dialog-title">选择城市</h2><button type="button" class="weather-close" aria-label="关闭天气">×</button></header><div class="weather-city-view"><p class="weather-privacy">选择城市即可查看天气；使用定位时只查询约公里级位置，不持续定位。</p><form class="weather-search"><input aria-label="搜索天气城市" placeholder="输入城市名，如杭州" maxlength="80"><button type="submit">搜索</button></form><button type="button" class="weather-locate">⌖ 使用当前位置</button><p class="weather-message" role="status"></p><div class="weather-city-results"></div><button type="button" class="weather-clear">关闭首页天气</button><p class="weather-attribution">城市检索数据：<a href="https://www.geonames.org/" target="_blank" rel="noopener noreferrer">GeoNames</a></p></div><div class="weather-detail-view" hidden><div class="weather-current"></div><p class="weather-provider-note" hidden></p><button type="button" class="weather-configure" hidden>设置和风天气</button><div class="weather-alerts"></div><p class="weather-detail-advice"></p><section class="weather-metrics-section"><h3>天气详情</h3><div class="weather-extra"></div></section><section class="weather-hours-section"><h3>逐小时预报 <small>左右滑动查看</small></h3><div class="weather-hours"></div></section><section class="weather-days-section"><h3 class="weather-days-heading">未来天气</h3><div class="weather-days"></div></section><section class="weather-life-section"><h3>生活建议 <small>和风生活指数</small></h3><div class="weather-indices"></div></section><p class="weather-updated"></p><div class="weather-detail-actions"><button type="button" class="weather-change">切换城市</button><button type="button" class="weather-refresh">刷新天气</button></div><p class="weather-attribution weather-source">天气数据：<a href="https://open-meteo.com/" target="_blank" rel="noopener noreferrer">Open-Meteo</a> · 预报仅供出行参考</p></div>';
  document.body.append(dialog);
  const $ = (s) => dialog.querySelector(s),
    results = $('.weather-city-results');
  let searchCtrl,
    searchId = 0,
    locationId = 0,
    previousFocus;
  let follow,
    locationNotice = '',
    latestState,
    userLocationIntent = 0;
  const invalidateLocation = () => {
    userLocationIntent++;
    follow?.invalidate();
  };
  const showCities = (rows) => {
    results.replaceChildren();
    for (const city of rows) {
      const b = node('button', undefined, 'weather-city-result');
      b.type = 'button';
      b.append(node('b', city.name), node('span', city.region || '中国'));
      b.onclick = () => {
        invalidateLocation();
        dialog.close();
        client.select(city).catch((error) => {
          $('.weather-message').textContent = error.message;
        });
      };
      results.append(b);
    }
  };
  function open(mode) {
    if (!dialog.open) previousFocus = document.activeElement;
    $('.weather-city-view').hidden = mode !== 'city';
    $('.weather-detail-view').hidden = mode === 'city';
    $('#weather-dialog-title').textContent = mode === 'city' ? '选择城市' : '天气与出行';
    if (mode === 'city') {
      showCities(POPULAR_CITIES);
      $('.weather-message').textContent = '常用城市';
    }
    if (!dialog.open) dialog.showModal();
  }
  root.querySelector('.home-weather-location').onclick = () => open('city');
  root.querySelector('.home-weather-details').onclick = () => open(client.state.city ? 'detail' : 'city');
  $('.weather-close').onclick = () => dialog.close();
  $('.weather-configure').onclick = () => {
    dialog.close();
    onConfigure?.();
  };
  $('.weather-change').onclick = () => open('city');
  $('.weather-clear').onclick = () => {
    invalidateLocation();
    client.clear();
    dialog.close();
  };
  $('.weather-refresh').onclick = async () => {
    const b = $('.weather-refresh');
    b.disabled = true;
    try {
      const changed = await follow.check({ force: true, foreground: true });
      if (!changed) await client.refresh({ force: true });
    } finally {
      b.disabled = false;
    }
  };
  $('.weather-search').onsubmit = async (e) => {
    e.preventDefault();
    const q = $('input').value.trim();
    if (q.length < 2) {
      $('.weather-message').textContent = '请输入至少两个字的城市名';
      return;
    }
    searchCtrl?.abort();
    searchCtrl = new AbortController();
    const id = ++searchId;
    $('.weather-message').textContent = '正在找城市…';
    try {
      const rows = await client.search(q, searchCtrl.signal);
      if (id !== searchId) return;
      showCities(rows);
      $('.weather-message').textContent = rows.length ? '选择对应的城市' : '暂未找到，可以输入完整城市名再试';
    } catch {
      if (id === searchId) $('.weather-message').textContent = '城市搜索暂不可用，可选择常用城市或稍后重试';
    }
  };
  $('.weather-locate').onclick = async () => {
    const b = $('.weather-locate'),
      id = ++locationId;
    b.disabled = true;
    invalidateLocation();
    $('.weather-message').textContent = '正在获取位置…';
    try {
      const city = await (locate === locateOnce ? locateWeatherCity({ maximumAge: 0 }) : locate({ maximumAge: 0 }));
      if (id !== locationId || !dialog.open) return;
      invalidateLocation();
      dialog.close();
      await client.select(city);
    } catch (error) {
      if (id === locationId) $('.weather-message').textContent = error.message || '无法定位，请手动选城市';
    } finally {
      b.disabled = false;
    }
  };
  dialog.addEventListener('close', () => {
    searchId++;
    locationId++;
    searchCtrl?.abort();
    previousFocus?.focus({ preventScroll: true });
  });
  dialog.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') e.stopPropagation();
  });
  const render = (state) => {
    latestState = state;
    // 后台刷新时照常显示上次的数据，不提“缓存”；只有真的没刷新成功才标出来
    const { city, data, status, error } = state,
      stale = !!(state.stale && error),
      kind = weatherKind(data?.code);
    root.querySelector('.home-city b').textContent = city ? (city.district || city.name).replace(/市$/, '') : '选择城市';
    root.querySelector('.home-city b').title = city?.name || '';
    const locationNote =
      city?.source === 'location' && !city.district ? state.locationError || '当前为粗略定位，区县名称暂未解析；可重新定位或手动选择区县。' : '';
    $('.weather-provider-note').hidden = !data?.providerNote && !locationNote && !locationNotice;
    $('.weather-provider-note').textContent = [data?.providerNote, locationNote, locationNotice].filter(Boolean).join('。');
    $('.weather-configure').hidden = !data?.providerNote || !onConfigure;
    root.querySelector('.home-weather-temp').textContent = data ? degrees(data.temp) : '—';
    root.querySelector('.home-weather-condition').textContent = weatherOverview(data, { stale });
    root
      .querySelector('.home-weather-details')
      .setAttribute('aria-label', city ? `查看${city.name}天气详情${data ? '，' + degrees(data.temp) : ''}` : '查看天气详情');
    root.querySelector('.home-weather-location').setAttribute('aria-label', city ? `切换天气位置，当前${city.name}` : '切换天气位置');
    root.querySelector('.home-weather-icon').innerHTML = weatherSVG(data ? kind.icon : 'cloud', data && !data.isDay);
    root.querySelector('.home-weather-summary').textContent = data
      ? `${stale ? '缓存 · ' : ''}${data.providerNote ? '基础天气 · 和风尚未配置完整' : weatherTravelAdvice(data, { stale })}`
      : status === 'loading'
        ? '正在看看天气…'
        : error
          ? '天气暂不可用，点击重试'
          : '选个城市，看看出门的天气';
    if (locationNotice) root.querySelector('.home-weather-summary').textContent += ' · 位置待更新';
    const advice = weatherTravelAdvice(data, { stale });
    onAdvice?.(advice);
    renderWeatherDetails(dialog, { city, data, status, stale, error, advice }, weatherSVG);
    $('.weather-updated').textContent = data ? `${stale ? '缓存数据 · ' : ''}资料时间 ${data.at.replace('T', ' ')}${error ? ' · ' + error : ''}` : error;
  };
  const unsubscribe = client.subscribe(render);
  let autoCancelled = false;
  const active = () => !autoCancelled && (globalThis.__jarvisForeground === true || (!document.hidden && globalThis.__jarvisForeground !== false));
  follow = createWeatherFollow({
    client,
    locate: quietLocate,
    checkPermission: checkLocation,
    now,
    active,
    onNotice: (text) => {
      locationNotice = text;
      render(latestState || client.state);
    }
  });
  // 仅首次无城市时申请权限；之后在已授权的前台静默检查，不重复弹授权框。
  let attempted = false;
  try {
    attempted = localStorage.getItem('jarvis.weather.locationAsked.v1') === '1';
  } catch {
    attempted = true;
  }
  const originalCity = client.state.city,
    originalKey = originalCity ? cityKey(originalCity) : '';
  const initialIntent = userLocationIntent;
  if (!originalCity && !attempted) {
    try {
      localStorage.setItem('jarvis.weather.locationAsked.v1', '1');
    } catch {}
    locate()
      .then((city) => {
        const current = client.state.city;
        if (
          !autoCancelled &&
          initialIntent === userLocationIntent &&
          ((!originalCity && !current) || (current?.source === 'location' && cityKey(current) === originalKey))
        )
          return client.select(city);
      })
      .catch(() => {
        if (!autoCancelled && !client.state.city) root.querySelector('.home-weather-summary').textContent = '定位暂不可用，可以手动选城市';
      });
  }
  const silentLocate = (options) => follow.check(options);
  const tick = (foreground = false) => {
    if (!active() || !root.isConnected) return;
    if (!follow.busy) client.refresh();
    silentLocate({ foreground });
  };
  const foreground = () => {
    if (active()) tick(true);
    else follow.cancel();
  };
  const nativeForeground = (event) => {
    if (event.detail?.active === true) foreground();
    else if (event.detail?.active === false) follow.cancel();
  };
  document.addEventListener('visibilitychange', foreground);
  globalThis.addEventListener('jarvis:foreground', nativeForeground);
  const timer = setInterval(() => tick(), WEATHER_AUTO_REFRESH);
  const locationTimer = setInterval(() => {
    if (active() && root.isConnected) silentLocate();
  }, WEATHER_LOCATION_INTERVAL);
  client.refresh();
  if (originalCity && active()) silentLocate({ foreground: true });
  return {
    silentLocate,
    root,
    destroy() {
      autoCancelled = true;
      follow.destroy();
      unsubscribe();
      searchId++;
      locationId++;
      searchCtrl?.abort();
      document.removeEventListener('visibilitychange', foreground);
      globalThis.removeEventListener('jarvis:foreground', nativeForeground);
      clearInterval(locationTimer);
      clearInterval(timer);
      dialog.remove();
    }
  };
}
